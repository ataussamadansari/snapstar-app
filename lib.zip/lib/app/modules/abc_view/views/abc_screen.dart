import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../controllers/abc_controller.dart';

class AbcScreen extends GetView<AbcController> {
  const AbcScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}
