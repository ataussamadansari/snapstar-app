import 'package:get/get.dart';

class AbcController extends GetxController {

}