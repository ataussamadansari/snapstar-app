import 'package:get/get.dart';

class SearchsController extends GetxController {

}