enum SubscribeState {
  none,          // no relation
  subscribed,    // I subscribed them
  subscribeBack, // They subscribed me
  mutual         // both subscribed
}
