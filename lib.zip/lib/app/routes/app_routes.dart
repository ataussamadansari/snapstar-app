abstract class Routes
{
    static const abc = '/abc';
    static const splash = '/splash';
    static const signup = '/signup';
    static const login = '/login';
    static const profileSetup = '/profile-setup';
    static const main = '/main';
    static const editProfile = '/edit-profile';
    static const subscriberList = '/subscribe-list';
    static const storyViewer = '/story-viewer';
}
